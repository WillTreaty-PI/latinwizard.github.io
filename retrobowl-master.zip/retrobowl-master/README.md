# Retro Bowl

Retro Bowl is a C#, Monogame American football game recreation based on the original Tecmo Bowl game created by Tecmo in 1987 for the arcades and Nintendo Entertainment System.

The game is as faithful as it can be to match the original arcade system and is playable on iOS, Android, MacOS, Linux, Windows, Windows Store, and Windows Phone.
